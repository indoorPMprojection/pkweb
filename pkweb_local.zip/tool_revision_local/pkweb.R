pathset<-getwd() # set current directory as working directory
if (!require('pkwebsupport')) {
  install.packages(paste0(pathset,"/pkwebsupport.zip"),repos = NULL, type = "win.binary")
}

library(pkwebsupport)
list.of.packages<-c("shiny","shinydashboard","readxl","DT","shinyalert","linpk","readr","nloptr","openxlsx","readxl",
               "linpk","zoo","shinyBS","minpack.lm","NonCompart","pkwebsupport")

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
for(name in list.of.packages){
#
   require(name,character.only = TRUE)
}



ind_code_path<<-paste0(pathset,"/tmp/","data_")
main_code_path<<-paste0(pathset,"/examples_data/")


#---------#Introduction--------
Module_introduction_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "introduction",
          fluidPage(
            uiOutput(ns("introduction"))
            
          )
  )
}

Module_introduction_Server <- function(input, output, session) {
  
  output$introduction<-renderUI({mainPanel(h2("Pkweb",align = "center",style = "font-family: 'Baskerville'; font-size: 380%; font-weight: 300"),
                                           h5("Pkweb is a freely available online application for a range of applications in pharmacokinetic (PK) data analysis: data simulation and paramter fit. This online tool also provides a portal for users
                                              to submit the PK data for specific contaminants or drugs. This project
                                              was developed by the research team in Beihang University. More details can be found in our manual.",style = "font-family: 'Lobster',cursive; font-weight: 200;
                                              line-height: 2.1; font-size: 150%"),
                                           br(),
                                           h5("If you have any questions on the use of this tool, pls email to dongzm@buaa.edu.cn. We will reply you within 1-3 business days. Meanwhile, for some data if cannot be solved by this online tool, pls contact our team for further assistance."
                                              ,style = "font-family: 'Lobster',cursive; font-weight: 200;
                                              line-height: 2.1; font-size: 150%; color: blue"))})
  }
#-------Simulation------------
# UI/Server for simulation_one
Module_simulation_one_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  
  fluidPage(
    fluidRow(
      box(title = "Step 1: Model_Selection", width = 4, solidHeader = TRUE, status = "primary",
          selectInput(ns('types'), 'Type',
                      c(bolus = "bolus", infusion = "infusion", extravascular="extravascular"),width=120),
          selectInput(ns("dosing"), 'dosing',c(single = "single", multiple_regular = "multiple_regular",
                                               multiple_irregular = "multiple_irregular"),width=150)),
      
      
      
      box(title = "Step 2: Timing", width = 4, solidHeader = TRUE, status = "primary",
          
          numericInput(ns('t_start'),'t_start(h)', 0,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_end'),'t_end(h)', 100,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_length'),'t_length(h)', 101,width=100,min=1,max=NA)
          #  conditionalPanel(condition=paste0("input['", ns("types"), "'] == 'extravascular_lag' "),
          #                  numericInput(ns("t_lag"), 't_lag',2,step=1,width=100,min=0,max=NA))
      )
    )
    ,
    
    fluidRow(
      
      
      box(title = "Step 3.1: Parameters_Basic", width = 4, solidHeader = TRUE, status = "info",
          numericInput(ns('vd'),'Vd(L)', 0.1,step=1,width=100,min=0,max=NA),
          numericInput(ns('ke'),'k10(1/h)', 0.01,step=0.1,width=100,min=0,max=NA),
          numericInput(ns('A0'),'Dose(mg)', 1,step=1,width=100,min=0,max=NA),
          conditionalPanel(condition=paste0("input['", ns("types"), "'] != 'bolus' "),
                           numericInput(ns('ka'),'ka(1/h)', 0.3,width=100,min=0,max=NA))
      ),
      box(title = "Step 3.2(Conditional): Parameters_Multiple dosing", width = 4, solidHeader = TRUE, status = "info",
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("interval"), 'interval(h)',2,step=1,width=100,min=0,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("times"), 'iteration times',2,step=1,width=100,min=1,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           fileInput(ns("multiple_upload"),'choose xlsx file for irregular dosing', accept = c("text/xlsx","text/comma-separated-values,text/plain",
                                                                                                               ".xlsx"))),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           downloadButton(ns('multiple_example'),"Templates",
                                          style="color: #FFFFFF; background-color: #339900; border-color: #339900")))
      
      
    ),
    fluidRow(
      box(title = "Step 4: Model_Simulation", width = 4, solidHeader = TRUE, status = "success",
          actionButton(ns('run'),'Run',width=100,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
          br(),
          br(),
          downloadButton(ns('downfile'),"Download results",style="color: #FFFFFF; background-color: #339900; border-color: #339900")
      )
    ),
    
    
    fluidRow(
      splitLayout(cellWidths = c("40%", "60%"),
                  imageOutput(ns('myImage')),
                  plotOutput(ns('simulation_one')))
    ),
    
    fluidRow(
      DT::dataTableOutput(ns("parameters"))
    )
    
  )
}

Module_simulation_one_Server <- function(input, output, session){
  
  observeEvent(input$types,{
    if (input$types=='infusion')
    {
      updateNumericInput(session, 'ka', 'T_infusion(h)' ,10,min=0,max=NA)
    }
    else if (input$types=='extravascular')
    {
      updateNumericInput(session, 'ka', 'ka(1/h)' ,0.3,min=0,max=NA)
    }
  }
  )
  
  
  output$multiple_example<-downloadHandler(filename = function(){
    paste("examples", ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(pathset,"/examples_data/simulation/simulation_input_example.xlsx"),con)
  })
  
  observeEvent(input$types,
               
               output$myImage<-renderImage({
                 filename <- normalizePath(file.path(paste0(main_code_path,"solver/single/one_",input$types,'.png'))) #download, need to refine
                 list(src = filename,width=640,height=360)
               },deleteFile = FALSE)
  )
  
  observeEvent(input$run,{
    #  t_lag_index<-0
    inFile<-NULL
    filepathtemp=paste0(ind_code_path,"one_",input$types,"_",input$dosing,".xlsx")
    if (input$types=='bolus' && input$dosing=='single')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd, dose=list(amt=input$A0))
      })
      
      
    }  else if (input$types=='infusion' && input$dosing=='single')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd, dose=list(amt=input$A0,dur=input$ka))
      })
      
    } else if (input$types=='extravascular' && input$dosing=='single')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, ka=input$ka,vc=input$vd, dose=list(amt=input$A0))
      })
    } else if (input$types=='extravascular_lag' && input$dosing=='single' && input$t_lag>=input$t_start)
    {
      t_lag_index<-input$t_lag
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start-input$t_lag,input$t_end-input$t_lag,length.out=input$t_length), cl=input$ke*input$vd, ka=input$ka,vc=input$vd, dose=list(amt=input$A0))
      })
    }
    
    else if (input$types=='bolus' && input$dosing=='multiple_regular')
    {
      
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd, dose=list(amt=input$A0,
                                                                                                                                     addl=input$times-1, ii=input$interval))
      })}  else if (input$types=='infusion' && input$dosing=='multiple_regular')
      {
        
        data_yplot<- reactive({
          data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd, dose=list(amt=input$A0, dur=input$ka,
                                                                                                                                       addl=input$times-1, ii=input$interval))
        })
      }  else if (input$types=='extravascular' && input$dosing=='multiple_regular')
      {
        data_yplot<- reactive({
          data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd, ka=input$ka,dose=list(amt=input$A0,                                                                                                                         addl=input$times-1, ii=input$interval))
        })
      } else if (input$types=='bolus' && input$dosing=='multiple_irregular')
      {
        
        inFile<-input$multiple_upload
        if (!is.null(inFile))
          
        {
          
          data_read_temp<-read_excel(inFile$datapath)
          colnames(data_read_temp)<-c("t.dose","amt")
          data_yplot<- reactive({
            data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                  cl=input$ke*input$vd, vc=input$vd, dose=list(amt=data_read_temp$amt,t.dose=data_read_temp$t.dose))
          })
        }
      } else if (input$types=='infusion' && input$dosing=='multiple_irregular')
      {
        
        inFile<-input$multiple_upload
        if (!is.null(inFile))
          
        {
          data_read_temp<-read_excel(inFile$datapath)
          colnames(data_read_temp)<-c("t.dose","amt")
          data_yplot<- reactive({
            data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                  cl=input$ke*input$vd, vc=input$vd, dose=list(t.dose=data_read_temp$t.dose,
                                                                               amt=data_read_temp$amt,dur=input$ka))
          })
        }
      } else if (input$types=='extravascular' && input$dosing=='multiple_irregular')
      {
        
        inFile<-input$multiple_upload
        if (!is.null(inFile))
          
        {
          data_read_temp<-read_excel(inFile$datapath)
          colnames(data_read_temp)<-c("t.dose","amt")
          data_yplot<- reactive({
            data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                  cl=input$ke*input$vd, vc=input$vd, ka=input$ka,dose=list(amt=data_read_temp$amt,t.dose=data_read_temp$t.dose))
          })
        }
      }
    
    if  ( input$dosing=='multiple_irregular' & is.null(inFile)){
      showModal(modalDialog(
        title = "Important message",
        "No file is uploaded for irregular dosing",
        easyClose = TRUE
      ))
    } else {
      
      data_show<-dat(data_yplot(),filepathtemp,input$ke*input$vd)
      cnames<-c("time(h)","con.(mg/L)","AUC(mg/L.h)","halflife(h)")
      colnames(data_show)[1:4]<-cnames
      write.xlsx(data_show,filepathtemp)
      output$simulation_one<-renderPlot({
        isolate(plot(data_yplot(),type='b',xlab='Time(h)',ylab='Concentration (mg/L)')+
                  title(main='The time course of concentrations'))
      })
      
      
      output$downfile<-downloadHandler(filename = function(){
        paste("result", gsub(":","-",Sys.time()),".xlsx", sep="")
      },
      content=function(con)
      {file.copy(filepathtemp,con)
      })
      
      
      
      output$parameters<-renderDT(
        datatable(data_show,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c("10",'30','60','90','120'))) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3)
      )
      
    }
  }
  )
}

#Ui/Server for simulation_two

Module_simulation_two_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  
  fluidPage(
    fluidRow(
      
      box(title = "Step 1: Model_selection", width = 4, solidHeader = TRUE, status = "primary",
          selectInput(ns('types'), 'Type',
                      c(bolus = "bolus", infusion = "infusion", extravascular="extravascular"),width=120),
          selectInput(ns("dosing"), 'dosing',c(single = "single", multiple_regular = "multiple_regular",
                                               multiple_irregular = "multiple_irregular"),width=150)),
      
      box(title = "Step 2: Timing", width = 4, solidHeader = TRUE, status = "primary",
          
          numericInput(ns('t_start'),'t_start(h)', 0,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_end'),'t_end(h)', 100,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_length'),'t_length(h)', 100,width=100,min=1,max=NA))
      
    ),
    
    fluidRow(
      
      box(title = "Step 3.1: Parameters_Basic", width = 4, solidHeader = TRUE, status = "info",
          
          numericInput(ns('vd'),'Vd(L)', 0.1,step=1,width=80,min=0,max=NA),
          numericInput(ns('ke'),'k10(1/h)', 0.01,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('A0'),'Dose(mg)', 1,step=1,width=80,min=0,max=NA),
          conditionalPanel(condition=paste0("input['", ns("types"), "'] != 'bolus' "),
                           numericInput(ns('ka'),'ka(1/h)', 0.3,width=80,min=0,max=NA))
      ),
      box(title = "Step 3.2: Parameters_Intercompartments", width = 4, solidHeader = TRUE, status = "info",
          numericInput(ns('k12'),'k12(1/h)', 0.1,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('k21'),'k21(1/h)', 0.1,step=0.1,width=80,min=0,max=NA)
      )
      ,
      
      box(title = "Step 3.3(Conditional): Parameters_Multiple dosing", width = 4, solidHeader = TRUE, status = "info",
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("interval"), 'interval(h)',2,step=1,width=100,min=0,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("times"), 'iteration times',2,step=1,width=100,min=1,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           fileInput(ns("multiple_upload"),'choose xlsx file for irregular dosing', accept = c("text/xlsx","text/comma-separated-values,text/plain",".xlsx"))),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           br(),
                           downloadButton(ns('multiple_example'),"Template",
                                          style="color: #fff; background-color: #337ab7; border-color: #2e6da4")))
    ),
    
    
    
    fluidRow(
      box(title = "Step 4: Model_simulation", width = 4, solidHeader = TRUE, status = "success",
          br(),
          actionButton(ns('run'),'Run',width=100,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
          br(),
          br(),
          downloadButton(ns('downfile'),"Download results",style="color: #FFFFFF; background-color: #339900; border-color: #339900"))
      
    ),
    
    fluidRow(
      splitLayout(cellWidths = c("40%", "60%"), imageOutput(ns('myImage')), plotOutput(ns('simulation_two')))
    ),
    
    fluidRow(
      DT::dataTableOutput(ns("parameters"))
    )
    
  )
}

Module_simulation_two_Server <- function(input, output, session){
  
  observeEvent(input$types,{
    if (input$types=='infusion')
    {
      updateNumericInput(session, 'ka', 'T_infusion(h)' ,10,min=0,max=NA)
    }
    else if (input$types=='extravascular')
    {
      updateNumericInput(session, 'ka', 'ka(1/h)' ,0.3,min=0,max=NA)
    }
  }
  )
  
  observeEvent(input$types,
               output$myImage<-renderImage({
                 filename <- normalizePath(file.path(paste0(main_code_path,"solver/single/two_",input$types,'.png'))) #download, need to refine
                 list(src = filename,width=640,height=360)
               },deleteFile = FALSE)
  )
  
  output$multiple_example<-downloadHandler(filename = function(){
    paste("examples", ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(pathset,"/examples_data/simulation/simulation_input_example.xlsx"),con)
  })
  
  observeEvent(input$run,{
    inFile<-NULL
    filepathtemp=paste0(ind_code_path,"two_",input$types,"_",input$dosing,".xlsx")
    
    if (input$types=='bolus' && input$dosing=='single')
    {
      
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,dose=list(amt=input$A0))
      })
    }   else if (input$types=='infusion' && input$dosing=='single')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,dose=list(amt=input$A0,dur=input$ka))
      })
    }  else if (input$types=='extravascular' && input$dosing=='single')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,ka=input$ka,dose=list(amt=input$A0))
      })
    }  else if (input$types=='bolus' && input$dosing=='multiple_regular')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21, dose=list(amt=input$A0,addl=input$times-1, ii=input$interval))
      })
    }  else if (input$types=='infusion' && input$dosing=='multiple_regular')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21, vc=input$vd, dose=list(amt=input$A0, dur=input$ka,addl=input$times-1, ii=input$interval))
      })
    } else if (input$types=='extravascular' && input$dosing=='multiple_regular')
    {
      data_yplot<- reactive({
        data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                              q=input$vd*input$k12,vp=input$vd*input$k12/input$k21, ka=input$ka,dose=list(amt=input$A0, addl=input$times-1, ii=input$interval))
      })
    }  else if (input$types=='bolus' && input$dosing=='multiple_irregular')
    {
      inFile<-input$multiple_upload
      if (!is.null(inFile))
      {
        data_read_temp<-read_excel(inFile$datapath)
        colnames(data_read_temp)<-c("t.dose","amt")
        data_yplot<- reactive({
          data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,
                                cl=input$ke*input$vd, vc=input$vd, dose=list(amt=data_read_temp$amt,t.dose=data_read_temp$t.dose))
        })
      }
    }   else if (input$types=='infusion' && input$dosing=='multiple_irregular')
    {
      inFile<-input$multiple_upload
      if (!is.null(inFile)){
        data_read_temp<-read_excel(inFile$datapath)
        colnames(data_read_temp)<-c("t.dose","amt")
        data_yplot<- reactive({
          data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,
                                cl=input$ke*input$vd, vc=input$vd, dose=list(t.dose=data_read_temp$t.dose,
                                                                             amt=data_read_temp$amt,dur=input$ka))
        })
      }
    } else if (input$types=='extravascular' && input$dosing=='multiple_irregular')
    {
      inFile<-input$multiple_upload
      if (!is.null(inFile)){
        data_read_temp<-read_excel(inFile$datapath)
        colnames(data_read_temp)<-c("t.dose","amt")
        
        data_yplot<- reactive({data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                                     q=input$vd*input$k12,vp=input$vd*input$k12/input$k21,
                                                     cl=input$ke*input$vd, vc=input$vd, ka=input$ka,dose=list(amt=data_read_temp$amt,t.dose=data_read_temp$t.dose))
        })
        
      }
    }
    
    if  ( input$dosing=='multiple_irregular' & is.null(inFile)){
      showModal(modalDialog(
        title = "Important message",
        "No file is uploaded for irregular dosing",
        easyClose = TRUE
      ))
    } else
    {
      data_show<-dat(data_yplot(),filepathtemp,input$ke*input$vd)
      cnames<-c("time(h)","con.(mg/L)","AUC(mg/L.h)","halflife(h)")
      colnames(data_show)[1:4]<-cnames
      write.xlsx(data_show,filepathtemp)
      output$simulation_two<-renderPlot({
        isolate(plot(data_yplot(),type='b',xlab='Time(h)',ylab='Concentration (mg/L)')+
                  title(main='The time course of concentrations'))
      })
      
      output$downfile<-downloadHandler(filename = function(){
        paste("result", gsub(":","-",Sys.time()),".xlsx", sep="")
      },
      content=function(con)
      {file.copy(filepathtemp,con)
      })
      output$parameters<-renderDT(
        datatable(data_show,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c("10",'30','60','90','120'))) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3)
      )
    }
  }
  )
}

#Ui/Server for simulation_three
Module_simulation_three_Ui<- function(id){
  ns <- NS(id) # Creates Namespace
  fluidPage(
    fluidRow(
      
      box(title = "Step 1: Model_selection", width = 4, solidHeader = TRUE, status = "primary",
          selectInput(ns('types'), 'Type',
                      c(bolus = "bolus", infusion = "infusion", extravascular="extravascular"),width=120),
          selectInput(ns("dosing"), 'dosing',c(single = "single", multiple_regular = "multiple_regular",
                                               multiple_irregular = "multiple_irregular"),width=150)),
      
      
      box(title = "Step 2: Timing", width = 4, solidHeader = TRUE, status = "primary",
          
          numericInput(ns('t_start'),'t_start(h)', 0,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_end'),'t_end(h)', 100,step=0,width=100,min=0,max=NA),
          numericInput(ns('t_length'),'t_length(h)', 100,width=100,min=1,max=NA))
    ),
    
    
    
    
    
    fluidRow(
      
      box(title = "Step 3.2: Parameters_Basic", width = 4, solidHeader = TRUE, status = "info",
          
          numericInput(ns('vd'),'Vd(L)', 0.1,step=1,width=80,min=0,max=NA),
          numericInput(ns('ke'),'k10(1/h)', 0.01,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('A0'),'Dose(mg)', 1,step=1,width=80,min=0,max=NA),
          conditionalPanel(condition=paste0("input['", ns("types"), "'] != 'bolus' "),
                           numericInput(ns('ka'),'ka(1/h)', 0.3,width=80,min=0,max=NA))),
      
      
      box(title = "Step 3.2: Parameters_Intercompartments", width = 4, solidHeader = TRUE, status = "info",
          numericInput(ns('k12'),'k12(1/h)', 0.1,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('k21'),'k21(1/h)', 0.1,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('k13'),'k13(1/h)', 0.1,step=0.1,width=80,min=0,max=NA),
          numericInput(ns('k31'),'k31(1/h)', 0.1,step=0.1,width=80,min=0,max=NA)
      ),
      
      box(title = "Step 3.3(Conditional): Parameters_Multiple dosing", width = 4, solidHeader = TRUE, status = "info",
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("interval"), 'interval(h)',2,step=1,width=100,min=0,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_regular' "),
                           numericInput(ns("times"), 'iteration times',2,step=1,width=100,min=1,max=NA)),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           fileInput(ns("multiple_upload"),'choose xlsx file for irregular dosing', accept = c("text/xlsx","text/comma-separated-values,text/plain",".xlsx"))),
          conditionalPanel(condition=paste0("input['", ns("dosing"), "'] == 'multiple_irregular' "),
                           br(),
                           downloadButton(ns('multiple_example'),"Template",
                                          style="color: #fff; background-color: #337ab7; border-color: #2e6da4")))
      
    ),
    fluidRow(
      box(title = "Step 4: Model_simulation", width = 4, solidHeader = TRUE, status = "success",
          br(),
          actionButton(ns('run'),'Run',width=100,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
          br(),
          br(),
          downloadButton(ns('downfile'),"Download results",style="color: #FFFFFF; background-color: #339900; border-color: #339900"))
      
    ),
    fluidRow(
      splitLayout(cellWidths = c("40%", "60%"), imageOutput(ns('myImage')), plotOutput(ns('simulation_three')))
    ),
    
    fluidRow(
      DT::dataTableOutput(ns("parameters"))
    )
    
  )
}

Module_simulation_three_Server <- function(input, output, session){
  
  observeEvent(input$types,{
    
    
    if (input$types=='infusion')
    {
      updateNumericInput(session, 'ka', 'T_infusion(h)' ,10,min=0,max=NA)
    }
    else if (input$types=='extravascular')
    {
      updateNumericInput(session, 'ka', 'ka(1/h)' ,0.3,min=0,max=NA)
    }
  }
  )
  
  observeEvent(input$types,
               output$myImage<-renderImage({
                 filename <- normalizePath(file.path(paste0(main_code_path,"solver/single/three_",input$types,'.png'))) #download, need to refine
                 list(src = filename,width=640,height=360)
               },deleteFile = FALSE)
  )
  
  output$multiple_example<-downloadHandler(filename = function(){
    paste("examples", ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(pathset,"/examples_data/simulation/simulation_input_example.xlsx"),con)
  })
  
  observeEvent(input$run,
               {
                 
                 inFile<-NULL
                 filepathtemp=paste0(ind_code_path,"three_",input$types,"_",input$dosing,".xlsx")
                 if (input$types=='bolus' && input$dosing=='single')
                 {
                   
                   data_yplot<- reactive({
                     data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                                           q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                           dose=list(amt=input$A0))
                   }) } else if (input$types=='infusion' && input$dosing=='single')
                   {
                     data_yplot<- reactive({
                       data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                                             q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                             dose=list(amt=input$A0,dur=input$ka))
                     })
                   } else if (input$types=='extravascular' && input$dosing=='single')
                   {
                     data_yplot<- reactive({
                       data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                                             q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                             ka=input$ka,dose=list(amt=input$A0))
                     })
                   } else if (input$types=='bolus' && input$dosing=='multiple_regular')
                   {
                     data_yplot<- reactive({
                       data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                                             q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31), dose=list(amt=input$A0,addl=input$times-1, ii=input$interval))
                     })
                   } else if (input$types=='infusion' && input$dosing=='multiple_regular')
                   {
                     data_yplot<- reactive({
                       data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd,
                                             q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),vc=input$vd, dose=list(amt=input$A0, dur=input$ka,addl=input$times-1, ii=input$interval))
                     })
                   } else if (input$types=='extravascular' && input$dosing=='multiple_regular')
                   {
                     data_yplot<- reactive({
                       data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), cl=input$ke*input$vd, vc=input$vd,
                                             q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),ka=input$ka,dose=list(amt=input$A0, addl=input$times-1, ii=input$interval))
                     })
                   } else if (input$types=='bolus' && input$dosing=='multiple_irregular')
                   {
                     inFile<-input$multiple_upload
                     if (!is.null(inFile))
                     {
                       data_read_temp<-read_excel(inFile$datapath)
                       colnames(data_read_temp)<-c("t.dose","amt")
                       data_yplot<- reactive({
                         data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length), q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                               cl=input$ke*input$vd, vc=input$vd, dose=list(t.dose=data_read_temp$t.dose,amt=data_read_temp$amt))
                       })
                     }
                   } else if (input$types=='infusion' && input$dosing=='multiple_irregular')
                   {
                     inFile<-input$multiple_upload
                     if (!is.null(inFile))
                     {
                       data_read_temp<-read_excel(inFile$datapath)
                       colnames(data_read_temp)<-c("t.dose","amt")
                       data_yplot<- reactive({
                         data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                               q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                               cl=input$ke*input$vd, vc=input$vd, dose=list(t.dose=data_read_temp$t.dose,
                                                                                            amt=data_read_temp$amt,dur=input$ka))
                       })
                     }
                   } else if (input$types=='extravascular' && input$dosing=='multiple_irregular')
                   {
                     inFile<-input$multiple_upload
                     if (!is.null(inFile))
                     {
                       data_read_temp<-read_excel(inFile$datapath)
                       colnames(data_read_temp)<-c("t.dose","amt")
                       data_yplot<- reactive({
                         data_yplot<-pkprofile(seq(input$t_start,input$t_end,length.out=input$t_length),
                                               q=c(input$vd*input$k12,input$vd*input$k13),vp=c(input$vd*input$k12/input$k21,input$vd*input$k13/input$k31),
                                               cl=input$ke*input$vd, vc=input$vd,ka=input$ka,dose=list(t.dose=data_read_temp$t.dose,
                                                                                                       amt=data_read_temp$amt))
                       })
                     }
                   }
                 if  ( input$dosing=='multiple_irregular' & is.null(inFile)){
                   showModal(modalDialog(
                     title = "Important message",
                     "No file is uploaded for irregular dosing",
                     easyClose = TRUE
                   ))
                 } else {
                   
                   data_show<-dat(data_yplot(),filepathtemp,input$ke*input$vd)
                   cnames<-c("time(h)","con.(mg/L)","AUC(mg/L.h)","halflife(h)")
                   colnames(data_show)[1:4]<-cnames
                   write_csv(data_show,filepathtemp)
                   output$simulation_three<-renderPlot({
                     isolate(plot(data_yplot(),type='b',xlab='Time(h)',ylab='concentration (mg/L)')+
                               title("The time course of concentrations"))
                   })
                   
                   
                   output$downfile<-downloadHandler(filename = function(){
                     paste("result", gsub(":","-",Sys.time()),".xlsx", sep="")
                   },
                   content=function(con)
                   {file.copy(filepathtemp,con)
                   })
                   
                   output$parameters<-renderDT(
                     datatable(data_show,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c("10",'30','60','90','120'))) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3)
                   )
                 }
               }
  )
}


#Ui/Server for simulation
Module_simulation_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "simulation", tabsetPanel(tabPanel("One Compartment",Module_simulation_one_Ui(ns("simulation_one"))),
                                              tabPanel("Two Compartments",Module_simulation_two_Ui(ns("simulation_two"))),
                                              tabPanel("Three Compartments",Module_simulation_three_Ui(ns("simulation_three")))))
}

Module_simulation_Server <- function(input, output, session){
  callModule(Module_simulation_one_Server,"simulation_one")
  callModule(Module_simulation_two_Server,"simulation_two")
  callModule(Module_simulation_three_Server,"simulation_three")
}

#-------classical solver-------------

#Ui/server for classical_single
Module_classical_single_Ui<-function(id) {ns<-NS(id)
fluidPage(fluidRow(
  box(title = "Step 1: Model_Selection", width = 4, solidHeader = TRUE, status = "primary",
      selectInput(ns('compartment'), label='Compartment',
                  c(one = "one", two = "two", three="three"),width=120),
      selectInput(ns('type'), label='Type',
                  c(bolus = "bolus", infusion = "infusion", extravascular="extravascular",extravascular_lag='extravascular_lag'),width=120)),
  box(title = "Step 2.0: Model_Input", width = 4, solidHeader = TRUE, status = "primary",
      selectInput(ns('data_input'), 'Data_Input',c(example='example',manually="manually",import="import"), width = 120),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                       numericInput(ns("num_data"), 'Number of Data Points',10,step=1,width=150,min=3,max=Inf)),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                       actionButton(ns("gen_data"), 'Click to generate data',width=180,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))),
  box(title = "Step 2.1(Conditional): Data_Upload", width = 4, solidHeader = TRUE, status = "primary",
      downloadButton(ns('data_upload_example'),"Download Template",width=120,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"),
      br(),
      br(),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                       fileInput(ns("data_upload"),'Choose xlsx File', width=180,accept = c(".xlsx"))
      ),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                       actionButton(ns("data_import"),'Click to upload data',width=180,
                                    style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))
  )),
  
  fluidRow(DT::dataTableOutput(ns("examples"))),
  fluidRow(
    
    box(title = "Step 3: Data_Check", width = 4, solidHeader = TRUE, status = "success",
        br(),
        actionButton(ns('check'),'Data Check',width=130,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        radioButtons(ns('check_result'),label=NULL,width=300,choices=c('No'),selected=('No'))),
    box(title = "Step 4: Model_Solver", width = 4, solidHeader = TRUE, status = "success",
        
        selectInput(ns('algorithm'), label='Algorithm',
                    c(General= "General", L_M = "L_M", BOBYQA="BOBYQA",G_N="G_N",plinear="plinear",port="port"),width=120),
        br(),
        actionButton(ns('run'),'Run',width=100,
                     style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        br(),
        downloadButton(ns('downfile'),"Download Results", style="color: #FFFFFF; background-color: #339900; border-color: #339900"))),
  
  fluidRow(
    splitLayout(cellWidths = c("55%", "45%"), imageOutput(ns('illustration')),
                imageOutput(ns('fitness')))
  ),
  fluidRow(DT::dataTableOutput(ns("result_show")))
)
}

Module_classical_single_Server<-function(input, output, session) {
  output$illustration<-renderImage({
    filename <- normalizePath(file.path(paste0(main_code_path, 'solver/single/',input$compartment,'_',input$type,'.png'))) #download, need to refine
    list(src = filename,width=640,height=360)
  },deleteFile = FALSE)
  output$data_upload_example<-downloadHandler(filename = function(){
    paste("examples_",input$compartment,'_',input$type, ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(main_code_path,'solver/single/',input$compartment,'_',input$type,'.xlsx'),con)
  })
  check_index<-0
  model_index_function<-reactive(
    {
      if (input$compartment=='one' & input$type=='bolus')
      {model_index<-1} else if (input$compartment=='one' & input$type=='infusion')
      {
        model_index<-2
      } else if (input$compartment=='one' & input$type=='extravascular')
      {
        model_index<-3
      } else if (input$compartment=='one' & input$type=='extravascular_lag')
      {
        model_index<-4
      } else if (input$compartment=='two' & input$type=='bolus')
      {
        model_index<-5
      } else if (input$compartment=='two' & input$type=='infusion')
      {
        model_index<-6
      } else if (input$compartment=='two' & input$type=='extravascular')
      {
        model_index<-7
      } else if (input$compartment=='two' & input$type=='extravascular_lag')
      {
        model_index<-8
      } else if (input$compartment=='three' & input$type=='bolus')
      {
        model_index<-9
      } else if (input$compartment=='three' & input$type=='infusion')
      {
        model_index<-10
      }
      return(model_index)
    }
  )
  observeEvent(input$gen_data,
               {
                 model_index<-model_index_function()
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 
                 data_show<-data_gen(model_index,num)
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=TRUE),editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               })
  observeEvent(input$data_import,
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 inFile<-input$data_upload
                 if (!is.null(inFile)) {
                   data_show<-read_excel(inFile$datapath)
                   colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                   output$examples<-renderDT(
                     datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                               editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                   filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                   write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 } else
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No file is slected to be uploaded",
                     easyClose = TRUE
                   ))
                 }
               }
               
  )
  observeEvent(input$compartment,
               
               if (input$data_input=='example')
               {
                 
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'solver/single/',input$compartment,'_',input$type,'.xlsx')
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen(model_index,num)
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=TRUE),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
  )
  
  observeEvent(input$compartment,
               
               if (input$compartment=='three')
               {updateSelectInput(session,'type','Type', c(bolus = "bolus", infusion = "infusion")
                                  ,selected=input$type)
               } else
               {
                 updateSelectInput(session,'type','Type', c(bolus = "bolus", infusion = "infusion",
                                                            extravascular='extravascular',extravascular_lag="extravascular_lag"),selected=input$type)
               }
  )
  
  observeEvent(input$type,
               
               if (input$type=='extravascular' | input$type=='extravascular_lag')
               {updateSelectInput(session,'compartment','Compartment', c(one = "one", two = "two"),selected=input$compartment
               )} else
               {
                 updateSelectInput(session,'compartment','Compartment',
                                   c(one = "one", two = "two",three="three"),selected=input$compartment)
               }
  )
  observeEvent(input$type,
               
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'/solver/single/',input$compartment,'_',input$type,'.xlsx')
                 
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen(model_index,num)
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
  )
  observeEvent(input$data_input,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'/solver/single/',input$compartment,'_',input$type,'.xlsx')
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               }   else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen(model_index,num)
                 colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
               
  )
  
  proxy = dataTableProxy('examples')
  
  
  
  observeEvent(input$examples_cell_edit, {
    
    filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
    data_show<-(read_excel(filetemp_write1))
    colnames(data_show)[1:4]<-c('t(h)',"con(mg/L)","dose(mg)","parameters")
    info = input$examples_cell_edit
    i = info$row
    j = info$col+1
    v = info$value
    data_show[i, j]<- DT::coerceValue(as.double(v), as.double(data_show[i, j]))
    write.xlsx(data_show,filetemp_write1,row.names = FALSE)
    updateRadioButtons(session,'check_result',choices='No',selected='No')
  }
  )
  observeEvent(input$check,
               {
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                 if (!file.exists(filetemp_write1))
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "Pls re-load or edit experimental data",
                     easyClose = TRUE))
                 } else
                 {
                   data_show<-(read_excel(filetemp_write1))
                   data_fit<-data_show
                   model_index<-model_index_function()
                   check_index1<-data_check_model(data_fit,model_index)
                   if (check_index1==1)
                   {updateRadioButtons(session,'check_result',choices='Yes',selected='Yes')}
                 }
               })
  observeEvent(input$run,
               {
                 if (input$check_result=='No')
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "pls finish data check",
                     easyClose = TRUE
                   ))
                 } else{
                   filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write.xlsx')
                   data_show<-(read_excel(filetemp_write1))
                   filename_xls<-paste0(ind_code_path,input$compartment,'_',input$type,'_for_run.xlsx')
                   img<-paste0(main_code_path, 'solver/single/',input$compartment,'_',input$type,'.png')
                   model_index<-model_index_function()
                   #  print(input$algorithm)
                   nls_res<-nls_define(data_show,filename_xls,model_index,img,input$algorithm,ind_code_path)
                   
                   if (!is.null(nls_res)){
                     showModal(modalDialog(
                       title = "Important message",
                       nls_res$msg_send,
                       easyClose = TRUE
                     ))
                     data_show_run<-read_excel(filename_xls, sheet = "fitness")
                     data_show_run<-data_show_run[,c(1,2,3,4,5,7,8,10,11)]
                     
                     output$fitness<-renderImage({
                       outfile <- tempfile(fileext='.png')
                       png(outfile, width = 400, height = 400)
                       plot(nls_res$plot_data$t,nls_res$plot_data$con,'l',col='blue',lwd=2,xlab='t(h)', main='Model fitness',
                            ylab='Con.(mg/L)',ylim=c(min(c(min(nls_res$plot_data$con),min(nls_res$predict[,2])))*0.8,
                                                     max(c(max(nls_res$plot_data$con),max(nls_res$predict[,2])))*1.2))+points(nls_res$predict[,1],nls_res$predict[,2],col='red',pch=19,cex=1)+
                         
                         dev.off()
                       list(src = outfile,width=400,height=400)
                     },deleteFile = FALSE)
                     
                     output$result_show<-renderDT(
                       datatable(data_show_run,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('30','60','90','120')),
                                 editable = FALSE) %>%   formatSignif(columns = c(1:ncol(data_show_run)), digits = 3))
                     
                     output$downfile<-downloadHandler(filename = function(){
                       paste("results",gsub(":","-",Sys.time()), ".xlsx", sep="")
                     },
                     content=function(con)
                     {file.copy(filename_xls,con)
                     })
                   } else {
                     
                     if (input$algorithm=='General')
                     {approach_name="Genearl"} else if (input$algorithm=="L_M")
                     {approach_name="Levenberg-Marquardt"} else if (input$algorithm=="G_N")
                     { approach_name="Gauss-Newton"} else if (input$algorithm=="plinear")
                     {approach_name="Plinear"} else if (input$algorithm=='port')
                     {
                       approach_name="Port"
                     }
                     
                     showModal(modalDialog(
                       title = "Important message",
                       paste0('Data is not suitable for fitness when using ',approach_name, " algorithm."),
                       easyClose = TRUE))
                     
                   }
                 }
               }
               
  )
  
}

# Ui/server: NCA

Module_classical_NCA_Ui<-function(id) {ns<-NS(id)
fluidPage(fluidRow(
  box(title = "Step 1: Model_Selection", width = 4, solidHeader = TRUE, status = "primary",
      selectInput(ns('type'), label='Type',
                  c(bolus = "bolus", infusion = "infusion", extravascular="extravascular"),width=120)),
  box(title = "Step 2.0: Model_Input", width = 4, solidHeader = TRUE, status = "primary",
      selectInput(ns('data_input'), 'Data_Input',c(example='example',manually="manually",import="import"), width = 120),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                       numericInput(ns("num_data"), 'Number of Data Points',10,step=1,width=150,min=3,max=Inf)),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                       actionButton(ns("gen_data"), 'Click to generate data',width=180,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))),
  box(title = "Step 2.1(Conditional): Data_Upload", width = 4, solidHeader = TRUE, status = "primary",
      downloadButton(ns('data_upload_example'),"Download Template",width=120,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"),
      br(),
      br(),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                       fileInput(ns("data_upload"),'Choose xlsx File', width=180,accept = c(".xlsx"))
      ),
      conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                       actionButton(ns("data_import"),'Click to upload data',width=180,
                                    style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))
  )),
  
  fluidRow(DT::dataTableOutput(ns("examples"))),
  fluidRow(
    
    box(title = "Step 3: Data_Check", width = 4, solidHeader = TRUE, status = "success",
        br(),
        actionButton(ns('check'),'Data Check',width=130,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        radioButtons(ns('check_result'),label=NULL,width=300,choices=c('No'),selected=('No'))),
    box(title = "Step 4: Model_Solver", width = 4, solidHeader = TRUE, status = "success",
        
        selectInput(ns('algorithm'), label='Algorithm',
                    c(linear= "linear", log = "log"),width=120),
        br(),
        actionButton(ns('run'),'Run',width=100,
                     style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        br(),
        downloadButton(ns('downfile'),"Download Results", style="color: #FFFFFF; background-color: #339900; border-color: #339900"))),
  
  
  fluidRow(DT::dataTableOutput(ns("result_show")))
)
}

Module_classical_NCA_Server<-function(input, output, session) {
  
  
  output$data_upload_example<-downloadHandler(filename = function(){
    paste("examples", ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(main_code_path,'solver/NCA/nca_',input$type,'.xlsx'),con)
  })
  
  observeEvent(input$gen_data,
               {
                 
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 if (num<1)
                 {
                   num=1
                 }
                 
                 data_show<-data.frame(t=1:num,con=1:num,dose=(c(1,rep(NA,num-1))))
                 colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=TRUE),editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               })
  
  observeEvent(input$data_input,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'/solver/NCA/nca_',input$type,'.xlsx')
                 
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 
                 data_show<-data.frame(t=1:num,con=1:num,dose=(c(1,rep(NA,num-1))))
                 colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
  )
  observeEvent(input$type,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'/solver/NCA/nca_',input$type,'.xlsx')
                 
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 
                 data_show<-data.frame(t=1:num,con=1:num,dose=(c(1,rep(NA,num-1))))
                 colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
  )
  
  observeEvent(input$data_import,
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 inFile<-input$data_upload
                 if (!is.null(inFile)) {
                   data_show<-read_excel(inFile$datapath)
                   colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
                   output$examples<-renderDT(
                     datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                               editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                   filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                   write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 } else
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No file is slected to be uploaded",
                     easyClose = TRUE
                   ))
                 }
               }
               
  )
  
  proxy = dataTableProxy('examples')
  
  
  
  observeEvent(input$examples_cell_edit, {
    filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
    data_show<-(read_excel(filetemp_write1))
    colnames(data_show)[1:3]<-c('t(h)',"con(mg/L)","dose(mg)")
    info = input$examples_cell_edit
    i = info$row
    j = info$col+1
    v = info$value
    data_show[i, j]<- DT::coerceValue(as.double(v), as.double(data_show[i, j]))
    write.xlsx(data_show,filetemp_write1,row.names = FALSE)
    updateRadioButtons(session,'check_result',choices='No',selected='No')
  }
  )
  
  observeEvent(input$check,
               {
                 filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                 data_show<-(read_excel(filetemp_write1))
                 data_fit<-data_show
                 
                 check_index1<-data_check_model_nca(data_fit)
                 if (check_index1==1)
                 {updateRadioButtons(session,'check_result',choices='Yes',selected='Yes')}
               })
  
  
  observeEvent(input$run,
               {
                 if (input$check_result=='No')
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "pls finish data check",
                     easyClose = TRUE
                   ))
                 } else{
                   filetemp_write1=paste0(ind_code_path,input$type,'_temp_write_nca.xlsx')
                   data_show<-(read_excel(filetemp_write1))
                   filename_xls<-paste0(ind_code_path,input$type,'_for_run_nca.xlsx')
                   
                   #  print(input$algorithm)
                   nls_res<-nls_define_nca(data_show,filename_xls,input$type,input$algorithm)
                   
                   if (!is.null(nls_res)){
                     showModal(modalDialog(
                       title = "Important message",
                       "model is fitted successfully by using NCA",
                       easyClose = TRUE
                     ))
                     data_show_run<-read_excel(filename_xls, sheet = "fitness")
                     data_show_run<-data_show_run[,c(1,2,3,5,6,8,9)]
                     
                     
                     
                     output$result_show<-renderDT(
                       datatable(data_show_run,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('30','60','90','120')),
                                 editable = FALSE) %>%   formatSignif(columns = c(1:ncol(data_show_run)), digits = 3))
                     
                     output$downfile<-downloadHandler(filename = function(){
                       paste("results",gsub(":","-",Sys.time()), ".xlsx", sep="")
                     },
                     content=function(con)
                     {file.copy(filename_xls,con)
                     })
                   } else {
                     
                     
                     
                     showModal(modalDialog(
                       title = "Important message",
                       'Data is not suitable for fitness by using NCA.',
                       easyClose = TRUE))
                     
                     
                   }
                 }
               }
               
  )
  
  
}


#Ui/server for multiple_dosing
Module_classical_multiple_Ui<-function(id) {ns<-NS(id)
fluidPage(
  fluidRow(
    box(title = "Step 1: Model_Selection", width = 4, solidHeader = TRUE, status = "primary",
        selectInput(ns('compartment'), label='Compartment',
                    c(one = "one", two = "two"),width=120),
        selectInput(ns('type'), label='Type',
                    c(bolus = "bolus",extravascular="extravascular"),width=120)),
    box(title = "Step 2.0: Model_Input", width = 4, solidHeader = TRUE, status = "primary",
        selectInput(ns('data_input'), 'Data_Input',c(example='example',manually="manually",import="import"), width = 120),
        conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                         numericInput(ns("num_data"), 'Number of Data Points',10,step=1,width=150,min=3,max=Inf)),
        conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'manually' "),
                         actionButton(ns("gen_data"), 'Click to generate data',width=180,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))),
    box(title = "Step 2.1(Conditional): Data_Upload", width = 4, solidHeader = TRUE, status = "primary",
        downloadButton(ns('data_upload_example'),"Download Template",width=120,style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"),
        br(),
        br(),
        conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                         fileInput(ns("data_upload"),'Choose xlsx File', width=180,accept = c(".xlsx"))
        ),
        conditionalPanel(condition=paste0("input['", ns("data_input"), "'] == 'import' "),
                         actionButton(ns("data_import"),'Click to upload data',width=180,
                                      style="color: #FFFFFF; background-color: #4783b3; border-color: #4783b3"))
    )),
  fluidRow(DT::dataTableOutput(ns("examples"))),
  fluidRow(
    
    box(title = "Step 3: Data_Check", width = 4, solidHeader = TRUE, status = "success",
        br(),
        actionButton(ns('check'),'Data Check',width=130,style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        radioButtons(ns('check_result'),label=NULL,width=300,choices=c('No'),selected=('No'))),
    box(title = "Step 4: Model_Solver", width = 4, solidHeader = TRUE, status = "success",
        
        selectInput(ns('algorithm'), label='Algorithm',
                    c(General= "General", L_M = "L_M", BOBYQA="BOBYQA",G_N="G_N"),width=120),
        br(),
        actionButton(ns('run'),'Run',width=100,
                     style="color: #FFFFFF; background-color: #339900; border-color: #339900"),
        br(),
        br(),
        br(),
        downloadButton(ns('downfile'),"Download Results", style="color: #FFFFFF; background-color: #339900; border-color: #339900"))),
  
  fluidRow(
    splitLayout(cellWidths = c("55%", "45%"), imageOutput(ns('illustration')),
                imageOutput(ns('fitness')))
  ),
  fluidRow(DT::dataTableOutput(ns("result_show")))
)

}

Module_classical_multiple_Server<-function(input, output, session) {
  output$illustration<-renderImage({
    filename <- normalizePath(file.path(paste0(main_code_path, 'solver/multiple/',input$compartment,'_',input$type,'.png'))) #download, need to refine
    list(src = filename,width=640,height=360)
  },deleteFile = FALSE)
  output$data_upload_example<-downloadHandler(filename = function(){
    paste("examples_",input$compartment,'_',input$type, ".xlsx", sep="")
  },
  content=function(con)
  {file.copy(paste0(main_code_path,'solver/multiple/',input$compartment,'_',input$type,'.xlsx'),con)
  })
  check_index<-0
  model_index_function<-reactive(
    {
      if (input$compartment=='one' & input$type=='bolus')
      {model_index<-13}  else if (input$compartment=='one' & input$type=='extravascular')
      {
        model_index<-15
      }  else if (input$compartment=='two' & input$type=='bolus')
      {
        model_index<-17
      }  else if (input$compartment=='two' & input$type=='extravascular')
      {
        model_index<-19
      }
      return(model_index)
    }
  )
  observeEvent(input$gen_data,
               {
                 model_index<-model_index_function()
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 
                 data_show<-data_gen_multiple(model_index,num)
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=TRUE),editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               })
  observeEvent(input$data_import,
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 inFile<-input$data_upload
                 if (!is.null(inFile)) {
                   data_show<-read_excel(inFile$datapath)
                   colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                   output$examples<-renderDT(
                     datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                               editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                   filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                   write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 } else
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "No file is slected to be uploaded",
                     easyClose = TRUE
                   ))
                 }
               }
               
  )
  observeEvent(input$compartment,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'solver/multiple/',input$compartment,'_',input$type,'.xlsx')
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen_multiple(model_index,num)
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=TRUE),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
  )
  
  
  
  observeEvent(input$type,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'/solver/multiple/',input$compartment,'_',input$type,'.xlsx')
                 
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               } else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen_multiple(model_index,num)
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
  )
  observeEvent(input$data_input,
               if (input$data_input=='example')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 filetemp=paste0(main_code_path,'solver/multiple/',input$compartment,'_',input$type,'.xlsx')
                 data_show<-(read_excel(filetemp))
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(
                     data_show,options = list(lengthChange = TRUE,lengthMenu=c('25','50','75','100'),autoWidth=FALSE),rownames=FALSE,
                     editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
               }   else  if (input$data_input=='manually')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
                 num=round(input$num_data)
                 model_index<-model_index_function()
                 data_show<-data_gen_multiple(model_index,num)
                 colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
                 output$examples<-renderDT(
                   datatable(data_show,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('25','50','75','100')),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 write.xlsx(data_show,filetemp_write1,row.names = FALSE)
                 
               }  else  if (input$data_input=='import')
               {
                 updateRadioButtons(session,'check_result',choices='No',selected='No')
               }
               
               
  )
  
  proxy = dataTableProxy('examples')
  
  
  
  observeEvent(input$examples_cell_edit, {
    
    filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
    data_show<-(read_excel(filetemp_write1))
    colnames(data_show)[1:5]<-c('t(h)',"con(mg/L)","dosing","dosing_values","parameters")
    info = input$examples_cell_edit
    i = info$row
    j = info$col+1
    v = info$value
    data_show[i, j]<- DT::coerceValue(as.double(v), as.double(data_show[i, j]))
    write.xlsx(data_show,filetemp_write1,row.names = FALSE)
    updateRadioButtons(session,'check_result',choices='No',selected='No')
  }
  )
  observeEvent(input$check,
               {
                 filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                 data_show<-(read_excel(filetemp_write1))
                 data_fit<-data_show
                 model_index<-model_index_function()
                 check_index1<-data_check_model_multiple(data_fit,model_index)
                 if (check_index1==1)
                 {updateRadioButtons(session,'check_result',choices='Yes',selected='Yes')}
               })
  observeEvent(input$run,
               {
                 if (input$check_result=='No')
                 {
                   showModal(modalDialog(
                     title = "Important message",
                     "pls finish data check",
                     easyClose = TRUE
                   ))
                 } else{
                   filetemp_write1=paste0(ind_code_path,input$compartment,'_',input$type,'_temp_write_multiple.xlsx')
                   data_show<-(read_excel(filetemp_write1))
                   filename_xls<-paste0(ind_code_path,input$compartment,'_',input$type,'_for_run_multiple.xlsx')
                   img<-paste0(main_code_path, 'solver/multiple/',input$compartment,'_',input$type,'.png')
                   model_index<-model_index_function()
                   #  print(input$algorithm)
                   nls_res<-nls_define_multiple(data_show,filename_xls,model_index,img,input$algorithm,ind_code_path)
                   
                   if (!is.null(nls_res)){
                     showModal(modalDialog(
                       title = "Important message",
                       nls_res$msg_send,
                       easyClose = TRUE
                     ))
                     data_show_run<-read_excel(filename_xls, sheet = "fitness")
                     data_show_run<-data_show_run[,c(1,2,3,4,5,7,8,10,11)]
                     
                     output$fitness<-renderImage({
                       outfile <- tempfile(fileext='.png')
                       png(outfile, width = 400, height = 400)
                       plot(nls_res$plot_data$t,nls_res$plot_data$con,'l',col='blue',lwd=2,xlab='t(h)', main='Model fitness',
                            ylab='Con.(mg/L)',ylim=c(min(c(min(nls_res$plot_data$con),min(nls_res$predict[,2])))*0.8,
                                                     max(c(max(nls_res$plot_data$con),max(nls_res$predict[,2])))*1.2))+points(nls_res$predict[,1],nls_res$predict[,2],col='red',pch=19,cex=1)+
                         
                         dev.off()
                       list(src = outfile,width=400,height=400)
                     },deleteFile = FALSE)
                     
                     output$result_show<-renderDT(
                       datatable(data_show_run,rownames=FALSE,options = list(lengthChange = TRUE,autoWidth=TRUE,lengthMenu=c('30','60','90','120')),
                                 editable = FALSE) %>%   formatSignif(columns = c(1:ncol(data_show_run)), digits = 3))
                     
                     output$downfile<-downloadHandler(filename = function(){
                       paste("results",gsub(":","-",Sys.time()), ".xlsx", sep="")
                     },
                     content=function(con)
                     {file.copy(filename_xls,con)
                     })
                   } else {
                     
                     if (input$algorithm=='General')
                     {approach_name="Genearl"} else if (input$algorithm=="L_M")
                     {approach_name="Levenberg-Marquardt"} else if (input$algorithm=="G_N")
                     { approach_name="Gauss-Newton"}
                     
                     showModal(modalDialog(
                       title = "Important message",
                       paste0('Data is not suitable for fitness when using ',approach_name, " algorithm."),
                       easyClose = TRUE))
                     
                   }
                 }
               }
               
  )
  
  
  
}
#Ui/Server for solver_UI
Module_solver_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "solver", tabsetPanel(tabPanel("Single_CA",Module_classical_single_Ui(ns("classical_single"))),
                                          tabPanel("Single_NCA",Module_classical_NCA_Ui(ns("NCA"))),
                                          tabPanel("Multiple_CA",Module_classical_multiple_Ui(ns("multiple")))))
}

Module_solver_Server <- function(input, output, session){
  callModule(Module_classical_single_Server,"classical_single")
  callModule(Module_classical_NCA_Server,"NCA")
  callModule(Module_classical_multiple_Server,"multiple")
}



#Ui/Server for database

Module_database_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "database", tabsetPanel(tabPanel("Basic info.",Module_database_basic_Ui(ns("basic"))),
                                            tabPanel("Database",Module_database_specific_Ui(ns("specific"))
                                            )
  ))
}

Module_database_Server <- function(input, output, session){
  callModule(Module_database_basic_Server,"basic")
  callModule(Module_database_specific_Server,"specific")
}


Module_database_basic_Ui <- function(id){
  ns <- NS(id) # Creates Namespace
  uiOutput(ns("basic"))
}

Module_database_basic_Server <- function(input, output, session){
  output$basic<-renderUI({mainPanel(h2("Database",align = "center",style = "font-family: 'Baskerville'; font-size: 380%; font-weight: 300"),
                                    h5("While some pharmacokinetics data for some existing chemicals were provided in this database, one aim of this online tool is to collect pharmacokinetics data
                                       for more chemicals based on crowdsourcing. We welcome users to submit specific data or parameters (via following email address) for international cooperation.Any format is welcome.
                                       After validation, we will update our database.",style = "font-family: 'Lobster',cursive; font-weight: 200;
                                       line-height: 2.1; font-size: 150%"),
                                    br(),
                                    h5("Our contact email: chaomi_87@163.com or dongzm@buaa.edu.cn",style = "font-family: 'Lobster',cursive; font-weight: 200;
                                       line-height: 2.1; font-size: 150%; color: blue"))})
  }


Module_database_specific_Ui<-function(id){
  ns <- NS(id)
  tabItem(tabName = "specific",
          fluidPage(
            
            fluidRow(DT::dataTableOutput(ns("total"))),
            fluidRow(textInput(ns('text'), label = h3("Enter ID for chemicals"),
                               value = NULL),  actionButton(ns('Display'), label = "Display",style="color: #FFFFFF; background-color: #339900; border-color: #339900")),
            uiOutput(ns("chemicals")),
            fluidRow(DT::dataTableOutput(ns("specify")))
          )
  )
}

Module_database_specific_Server <- function(input, output, session) {
  data_show<-read_excel(paste0(main_code_path,"database/total_all_chemicals.xlsx"))
  output$total<-renderDT(
    datatable(data_show,rownames=FALSE,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=TRUE),
              editable = TRUE))
  
  observeEvent(input$Display,
               
               if (file.exists(paste0(main_code_path,"database/chemicals/",as.character(input$text),".xlsx")))
               {
                 output$chemicals<- renderUI(
                   {
                     data_show<-read_excel(paste0(main_code_path,"database/total_all_chemicals.xlsx"))
                     h2(paste0("Model information for ",data_show[as.numeric(input$text),2]))
                   }
                 )
                 data_show1<-read_excel(paste0(main_code_path,"database/chemicals/",input$text,".xlsx"))
                 output$specify<-renderDT(
                   datatable(data_show1,rownames=FALSE,options = list(lengthMenu=c('25','50','75','100'),lengthChange = TRUE,autoWidth=TRUE),
                             editable = TRUE) %>%   formatSignif(columns = c(1:ncol(data_show)), digits = 3))
               } else
               {
                 
                 
                 showModal(modalDialog(
                   title = "Important message",
                   "The input ID for chemicals is invalid",
                   easyClose = TRUE))
               }
  )
}







#-----main framework-------------
ui <- dashboardPage(
  dashboardHeader(),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introduction", tabName="introduction"),
      menuItem("Simulation", tabName = "simulation"),
      menuItem("Solver", tabName = "solver"),
      menuItem("Database", tabName = "database")
    )
  ),
  dashboardBody(
    tabItems(
      Module_introduction_Ui("introduction"),
      Module_simulation_Ui("simulation"),
      Module_solver_Ui("solver"),
      Module_database_Ui("database")
    )))

server <- function(input,output,server){
  callModule(Module_introduction_Server,"introduction")
  callModule(Module_simulation_Server,"simulation")
  callModule(Module_solver_Server,"solver")
  callModule(Module_database_Server,"database")
}

shinyApp(ui,server)